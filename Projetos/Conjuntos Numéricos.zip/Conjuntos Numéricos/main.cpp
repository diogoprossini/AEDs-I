/* 
 * File:   main.cpp
 * Author: 2024.1.08.024
 *
 * Created on 23 de abril de 2024, 13:02
 */

#include <fstream>
#include <math.h>
#include <iostream>
#include <stdio.h>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv){

    int conjunto1[10] = {5, 4, 2, 5, 3, 2, 4, 8, 2, 9};
    int conjunto2[10] = {7, 1, 12, 10, 9, 2, 8, 1, 2, 7};
    
    int tam1 = 10, tam2 = 10;
    
    cout << "Operações em conjuntos de valores." << endl;
    
    return 0;
}


